def main():
    menus = input("1. Login  2. Register  3. Quit = ")
    code = input("Login Code = ")
    sith = input().replace("1", "")
    menu = input("1. Login  2. Register  3. Quit = ")
    login = input().replace("","")


    if menus == 1:
        input(code)
    if input == sith:
        input(menus)
    else:
        input("")

    if menus == "grogu":
        print("Password: ")
    else:
        print("Username: ")

main()